let elemento = document.querySelector('#titulo-principal');




elemento.
setTimeout(function(){

    elemento.computedStyleMap.color = 'green';
    elemento.computedStyleMap.backgroundColor = 'blue';
    elemento.computedStyleMap.widht = '400px';
    
},1000);

