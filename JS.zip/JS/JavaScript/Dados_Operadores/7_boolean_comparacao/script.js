console.log(1 > 2);
console.log(2 < 10);
console.log(3 >= 3);
console.log(5 <= 4);
// console.log(3 == 2);//igualdade
// console.log('José' != 'Juca');//diferente
// console.log(3 === '3');




