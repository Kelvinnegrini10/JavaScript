console.log(typeof 5);
console.log(typeof 12.7);
console.log(typeof -23);
