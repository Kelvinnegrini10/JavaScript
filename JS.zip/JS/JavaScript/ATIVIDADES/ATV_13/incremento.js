// Incremento de 1 a 10
let n = 1;

while (n <= 10) {
    console.log(n);
    n++; 
}

// Decremento de 10 a 1
let number = 10;

while (number >= 1) {
    console.log(number);
    number--;   
}
    
