let nota = Number(prompt("insira sua nota:"))

if(nota >= 7){
    alert("Aprovado");
}else{
    alert("Reprovado");
    
}

