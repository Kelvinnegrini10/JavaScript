alert("Bem vindos")


let idade = Number(prompt("insira sua idade:"))

if (idade >= 18){
  alert("Maior de idade")
}else{
  alert("Menor de idade ")
}


