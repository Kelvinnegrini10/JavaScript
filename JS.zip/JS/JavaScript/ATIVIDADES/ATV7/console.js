console.log("Esta é uma mensagem de log.");
console.warn("Este é um aviso!");          
console.error("Ocorreu um erro!");           

