console.log(typeof 'Kelvin');
console.log(typeof 4);
console.log(5 > 2 && 5 < 2 );
console.log(null);
console.log(undefined);






