let num = Math.floor(Math.random() * 100) + 1; 
console.log(num);

let numero = Math.sqrt(9)
console.log(numero); 

