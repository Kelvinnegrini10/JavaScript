let nome = prompt("Seu nome")
console.log(`Seja bem vindo ${nome}`);

let n1 = Number(prompt("Insira n1"))
let n2 = Number(prompt("Insira n2"))
let soma = n1 + n2
console.log(`a soma é: ${soma}`);
