let x = 10;
while(x > 0 );{
    console.log("O x é " + x);
    
}
let y = 0
while (y <= 10){
    console.log(y);
    y = y + 1;
}

let z = 10;
while (z > 0){
    console.log(z);
    
}










