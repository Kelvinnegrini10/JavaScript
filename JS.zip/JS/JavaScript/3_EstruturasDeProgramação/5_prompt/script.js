
let nome = prompt("Qual seu nome?")
console.log(nome);

let idade = prompt("Qual sua idade?")
console.log(idade);










