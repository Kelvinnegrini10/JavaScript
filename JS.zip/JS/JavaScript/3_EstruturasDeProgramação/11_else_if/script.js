let nome = "Juca";
let idade = 28;

if(nome != undefined && nome == "Joaquim"){
    console.log("Nome esta definido");
}else if(nome != undefined && nome.length > 5 && idade == 50){
    console.log("Meu nome é Juca"); 
}else{
    console.log("não é Juca");
   
}
    

if(nome != undefined && nome.length > 5 && idade == 50){
    console.log("meu nome é Juca");
}else{
    console.log("não é o Juca");
}













