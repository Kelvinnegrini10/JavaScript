let nome = "Joana";

console.log(nome);
console.log(`O meu nome é: ${nome}`);

let laranjas = 8974;
console.log(laranjas);

nome = "João";
console.log(nome);

let um = 1,dois = 2, tres = 3;
let t1 = 'ola', t2 = 'pessoal';
console.log(t1 + t2);

console.log(um, dois, tres);























