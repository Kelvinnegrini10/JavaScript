let novoElemento = document.createElement('p');
let texto = document.createTextNode('Olá Turma!');
novoElemento.appendChild(texto);

let heading = document.querySelector('#titulo-principal');
let paiHeading = heading.parentNode;

paiHeading.removeChild(novoElemento, heading);