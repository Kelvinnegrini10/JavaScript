let itens = document.querySelectorAll('.itens-vermelhos');

for (let i = 0; i < 3 && i < itens.length; i++) {
    itens[i].style.color = 'red';
    console.log(`Cor do item ${i + 1}:`, itens[i].style.color);
}

let itens2 = document.querySelectorAll('.itens-azuis');

itens2.forEach(item => {
    item.style.color = 'blue';
});